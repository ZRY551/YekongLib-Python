# Import all the functions from the hash modules
from . import MD5
from . import SHA256
from . import SHA384
from . import SHA512
