# YekongLib-Python

一个使用Python语言编写的轻量的库，提供多种工具给开发者使用。

随 YekongLib-CSharp 持续更新。